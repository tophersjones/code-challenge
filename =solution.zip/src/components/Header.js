import React from 'react'

const Header = () => (
  <div>
    <p className='header'>G2 Crowd Team Roster</p>
    <hr className='topHr'/>
  </div>
  )

export default Header
